package br.com.unipac.doar_me.model.entity

data class Pessoa(
    var id: Int = 0,
    var name: String = ""
)
