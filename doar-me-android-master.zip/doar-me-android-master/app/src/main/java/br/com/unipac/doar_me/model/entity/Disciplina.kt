package br.com.unipac.doar_me.model.entity

data class Disciplina(
    var id: Int = 0,
    var name: String = ""
)
